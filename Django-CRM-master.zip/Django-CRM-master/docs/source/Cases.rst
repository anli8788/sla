Cases
*****



|  **Fig** cases Home Page

|  The above figure shows the cases view, this page gives details and list view of leads
|  You can filter the results by name, status, priority, account.

|  Create a new Lead using the button on right corner ``+ Add New case``


|  **Fig** cases Create Page

|  **Note:** Fields having ``*`` are mandatory.

|  **Note:** To create a cases user,accounts are required.
from slaclient.templates.xifi.xifi import TemplateInput
from slaclient.templates.xifi.xifi import AgreementInput
from slaclient.templates.xifi.xifi import render_slaagreement
from slaclient.templates.xifi.xifi import render_slatemplate
